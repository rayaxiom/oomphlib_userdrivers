#!/bin/bash


## NPROC IS 1
# qsub folder, nproc, coarse
NPROC="1"
COARSE="1"
RESLT1=$(./get_times.sh test1/qsub_output ${NPROC} ${COARSE})
RESLT2=$(./get_times.sh test2/qsub_output ${NPROC} ${COARSE})
RESLT3=$(./get_times.sh test3/qsub_output ${NPROC} ${COARSE})
paste <(echo "$RESLT1") <(echo "$RESLT2") <(echo "$RESLT3") > NP${NPROC}C${COARSE}

# qsub folder, nproc, coarse
COARSE="2"
RESLT1=$(./get_times.sh test1/qsub_output ${NPROC} ${COARSE})
RESLT2=$(./get_times.sh test2/qsub_output ${NPROC} ${COARSE})
RESLT3=$(./get_times.sh test3/qsub_output ${NPROC} ${COARSE})
paste <(echo "$RESLT1") <(echo "$RESLT2") <(echo "$RESLT3") > NP${NPROC}C${COARSE}

# qsub folder, nproc, coarse
COARSE="3"
RESLT1=$(./get_times.sh test1/qsub_output ${NPROC} ${COARSE})
RESLT2=$(./get_times.sh test2/qsub_output ${NPROC} ${COARSE})
RESLT3=$(./get_times.sh test3/qsub_output ${NPROC} ${COARSE})
paste <(echo "$RESLT1") <(echo "$RESLT2") <(echo "$RESLT3") > NP${NPROC}C${COARSE}

# qsub folder, nproc, coarse
COARSE="4"
RESLT1=$(./get_times.sh test1/qsub_output ${NPROC} ${COARSE})
RESLT2=$(./get_times.sh test2/qsub_output ${NPROC} ${COARSE})
RESLT3=$(./get_times.sh test3/qsub_output ${NPROC} ${COARSE})
paste <(echo "$RESLT1") <(echo "$RESLT2") <(echo "$RESLT3") > NP${NPROC}C${COARSE}

# qsub folder, nproc, coarse
COARSE="5"
RESLT1=$(./get_times.sh test1/qsub_output ${NPROC} ${COARSE})
RESLT2=$(./get_times.sh test2/qsub_output ${NPROC} ${COARSE})
RESLT3=$(./get_times.sh test3/qsub_output ${NPROC} ${COARSE})
paste <(echo "$RESLT1") <(echo "$RESLT2") <(echo "$RESLT3") > NP${NPROC}C${COARSE}

############################################################################

## NPROC IS 2
# qsub folder, nproc, coarse
NPROC="2"
COARSE="1"
RESLT1=$(./get_times.sh test1/qsub_output ${NPROC} ${COARSE})
RESLT2=$(./get_times.sh test2/qsub_output ${NPROC} ${COARSE})
RESLT3=$(./get_times.sh test3/qsub_output ${NPROC} ${COARSE})
paste <(echo "$RESLT1") <(echo "$RESLT2") <(echo "$RESLT3") > NP${NPROC}C${COARSE}

# qsub folder, nproc, coarse
COARSE="2"
RESLT1=$(./get_times.sh test1/qsub_output ${NPROC} ${COARSE})
RESLT2=$(./get_times.sh test2/qsub_output ${NPROC} ${COARSE})
RESLT3=$(./get_times.sh test3/qsub_output ${NPROC} ${COARSE})
paste <(echo "$RESLT1") <(echo "$RESLT2") <(echo "$RESLT3") > NP${NPROC}C${COARSE}

# qsub folder, nproc, coarse
COARSE="3"
RESLT1=$(./get_times.sh test1/qsub_output ${NPROC} ${COARSE})
RESLT2=$(./get_times.sh test2/qsub_output ${NPROC} ${COARSE})
RESLT3=$(./get_times.sh test3/qsub_output ${NPROC} ${COARSE})
paste <(echo "$RESLT1") <(echo "$RESLT2") <(echo "$RESLT3") > NP${NPROC}C${COARSE}

# qsub folder, nproc, coarse
COARSE="4"
RESLT1=$(./get_times.sh test1/qsub_output ${NPROC} ${COARSE})
RESLT2=$(./get_times.sh test2/qsub_output ${NPROC} ${COARSE})
RESLT3=$(./get_times.sh test3/qsub_output ${NPROC} ${COARSE})
paste <(echo "$RESLT1") <(echo "$RESLT2") <(echo "$RESLT3") > NP${NPROC}C${COARSE}

# qsub folder, nproc, coarse
COARSE="5"
RESLT1=$(./get_times.sh test1/qsub_output ${NPROC} ${COARSE})
RESLT2=$(./get_times.sh test2/qsub_output ${NPROC} ${COARSE})
RESLT3=$(./get_times.sh test3/qsub_output ${NPROC} ${COARSE})
paste <(echo "$RESLT1") <(echo "$RESLT2") <(echo "$RESLT3") > NP${NPROC}C${COARSE}

############################################################################
## NPROC IS 4
# qsub folder, nproc, coarse
NPROC="4"
COARSE="1"
RESLT1=$(./get_times.sh test1/qsub_output ${NPROC} ${COARSE})
RESLT2=$(./get_times.sh test2/qsub_output ${NPROC} ${COARSE})
RESLT3=$(./get_times.sh test3/qsub_output ${NPROC} ${COARSE})
paste <(echo "$RESLT1") <(echo "$RESLT2") <(echo "$RESLT3") > NP${NPROC}C${COARSE}

# qsub folder, nproc, coarse
COARSE="2"
RESLT1=$(./get_times.sh test1/qsub_output ${NPROC} ${COARSE})
RESLT2=$(./get_times.sh test2/qsub_output ${NPROC} ${COARSE})
RESLT3=$(./get_times.sh test3/qsub_output ${NPROC} ${COARSE})
paste <(echo "$RESLT1") <(echo "$RESLT2") <(echo "$RESLT3") > NP${NPROC}C${COARSE}

# qsub folder, nproc, coarse
COARSE="3"
RESLT1=$(./get_times.sh test1/qsub_output ${NPROC} ${COARSE})
RESLT2=$(./get_times.sh test2/qsub_output ${NPROC} ${COARSE})
RESLT3=$(./get_times.sh test3/qsub_output ${NPROC} ${COARSE})
paste <(echo "$RESLT1") <(echo "$RESLT2") <(echo "$RESLT3") > NP${NPROC}C${COARSE}

# qsub folder, nproc, coarse
COARSE="4"
RESLT1=$(./get_times.sh test1/qsub_output ${NPROC} ${COARSE})
RESLT2=$(./get_times.sh test2/qsub_output ${NPROC} ${COARSE})
RESLT3=$(./get_times.sh test3/qsub_output ${NPROC} ${COARSE})
paste <(echo "$RESLT1") <(echo "$RESLT2") <(echo "$RESLT3") > NP${NPROC}C${COARSE}

# qsub folder, nproc, coarse
COARSE="5"
RESLT1=$(./get_times.sh test1/qsub_output ${NPROC} ${COARSE})
RESLT2=$(./get_times.sh test2/qsub_output ${NPROC} ${COARSE})
RESLT3=$(./get_times.sh test3/qsub_output ${NPROC} ${COARSE})
paste <(echo "$RESLT1") <(echo "$RESLT2") <(echo "$RESLT3") > NP${NPROC}C${COARSE}

############################################################################
## NPROC IS 8
# qsub folder, nproc, coarse
NPROC="8"
COARSE="1"
RESLT1=$(./get_times.sh test1/qsub_output ${NPROC} ${COARSE})
RESLT2=$(./get_times.sh test2/qsub_output ${NPROC} ${COARSE})
RESLT3=$(./get_times.sh test3/qsub_output ${NPROC} ${COARSE})
paste <(echo "$RESLT1") <(echo "$RESLT2") <(echo "$RESLT3") > NP${NPROC}C${COARSE}

# qsub folder, nproc, coarse
COARSE="2"
RESLT1=$(./get_times.sh test1/qsub_output ${NPROC} ${COARSE})
RESLT2=$(./get_times.sh test2/qsub_output ${NPROC} ${COARSE})
RESLT3=$(./get_times.sh test3/qsub_output ${NPROC} ${COARSE})
paste <(echo "$RESLT1") <(echo "$RESLT2") <(echo "$RESLT3") > NP${NPROC}C${COARSE}

# qsub folder, nproc, coarse
COARSE="3"
RESLT1=$(./get_times.sh test1/qsub_output ${NPROC} ${COARSE})
RESLT2=$(./get_times.sh test2/qsub_output ${NPROC} ${COARSE})
RESLT3=$(./get_times.sh test3/qsub_output ${NPROC} ${COARSE})
paste <(echo "$RESLT1") <(echo "$RESLT2") <(echo "$RESLT3") > NP${NPROC}C${COARSE}

# qsub folder, nproc, coarse
COARSE="4"
RESLT1=$(./get_times.sh test1/qsub_output ${NPROC} ${COARSE})
RESLT2=$(./get_times.sh test2/qsub_output ${NPROC} ${COARSE})
RESLT3=$(./get_times.sh test3/qsub_output ${NPROC} ${COARSE})
paste <(echo "$RESLT1") <(echo "$RESLT2") <(echo "$RESLT3") > NP${NPROC}C${COARSE}

# qsub folder, nproc, coarse
COARSE="5"
RESLT1=$(./get_times.sh test1/qsub_output ${NPROC} ${COARSE})
RESLT2=$(./get_times.sh test2/qsub_output ${NPROC} ${COARSE})
RESLT3=$(./get_times.sh test3/qsub_output ${NPROC} ${COARSE})
paste <(echo "$RESLT1") <(echo "$RESLT2") <(echo "$RESLT3") > NP${NPROC}C${COARSE}

############################################################################
## NPROC IS 16
# qsub folder, nproc, coarse
NPROC="16"
COARSE="1"
RESLT1=$(./get_times.sh test1/qsub_output ${NPROC} ${COARSE})
RESLT2=$(./get_times.sh test2/qsub_output ${NPROC} ${COARSE})
RESLT3=$(./get_times.sh test3/qsub_output ${NPROC} ${COARSE})
paste <(echo "$RESLT1") <(echo "$RESLT2") <(echo "$RESLT3") > NP${NPROC}C${COARSE}

# qsub folder, nproc, coarse
COARSE="2"
RESLT1=$(./get_times.sh test1/qsub_output ${NPROC} ${COARSE})
RESLT2=$(./get_times.sh test2/qsub_output ${NPROC} ${COARSE})
RESLT3=$(./get_times.sh test3/qsub_output ${NPROC} ${COARSE})
paste <(echo "$RESLT1") <(echo "$RESLT2") <(echo "$RESLT3") > NP${NPROC}C${COARSE}

# qsub folder, nproc, coarse
COARSE="3"
RESLT1=$(./get_times.sh test1/qsub_output ${NPROC} ${COARSE})
RESLT2=$(./get_times.sh test2/qsub_output ${NPROC} ${COARSE})
RESLT3=$(./get_times.sh test3/qsub_output ${NPROC} ${COARSE})
paste <(echo "$RESLT1") <(echo "$RESLT2") <(echo "$RESLT3") > NP${NPROC}C${COARSE}

# qsub folder, nproc, coarse
COARSE="4"
RESLT1=$(./get_times.sh test1/qsub_output ${NPROC} ${COARSE})
RESLT2=$(./get_times.sh test2/qsub_output ${NPROC} ${COARSE})
RESLT3=$(./get_times.sh test3/qsub_output ${NPROC} ${COARSE})
paste <(echo "$RESLT1") <(echo "$RESLT2") <(echo "$RESLT3") > NP${NPROC}C${COARSE}

# qsub folder, nproc, coarse
COARSE="5"
RESLT1=$(./get_times.sh test1/qsub_output ${NPROC} ${COARSE})
RESLT2=$(./get_times.sh test2/qsub_output ${NPROC} ${COARSE})
RESLT3=$(./get_times.sh test3/qsub_output ${NPROC} ${COARSE})
paste <(echo "$RESLT1") <(echo "$RESLT2") <(echo "$RESLT3") > NP${NPROC}C${COARSE}





























