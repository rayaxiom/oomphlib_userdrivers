#!/bin/bash
set -u

CURRENTDIR=`pwd`

## Change this for each folder.
RESDIR=""
PRECSIM=""
PRECSTR=""
TAG=""



function get_results()
{

############################################
cd $RESDIR


LINE=""
VISC="Sim"

RESFILE="CuPo${VISC}R200${PRECSIM}A67N4*"
TOKEN=$(grep "$TAG" $RESFILE | awk '{print $NF}')
LINE="$LINE $TOKEN"


RESFILE="CuPo${VISC}R200${PRECSIM}A67N6*"
TOKEN=$(grep "$TAG" $RESFILE | awk '{print $NF}')
LINE="$LINE $TOKEN"


RESFILE="CuPo${VISC}R200${PRECSIM}A67N8*"
TOKEN=$(grep "$TAG" $RESFILE | awk '{print $NF}')
LINE="$LINE $TOKEN"


RESFILE="CuPo${VISC}R200${PRECSIM}A67N10*"
TOKEN=$(grep "$TAG" $RESFILE | awk '{print $NF}')
LINE="$LINE $TOKEN"


RESFILE="CuPo${VISC}R200${PRECSIM}A67N12*"
TOKEN=$(grep "$TAG" $RESFILE | awk '{print $NF}')
LINE="$LINE $TOKEN"


RESFILE="CuPo${VISC}R200${PRECSIM}A67N14*"
TOKEN=$(grep "$TAG" $RESFILE | awk '{print $NF}')
LINE="$LINE $TOKEN"


RESFILE="CuPo${VISC}R200${PRECSIM}A67N16*"
TOKEN=$(grep "$TAG" $RESFILE | awk '{print $NF}')
LINE="$LINE $TOKEN"


RESFILE="CuPo${VISC}R200${PRECSIM}A67N18*"
TOKEN=$(grep "$TAG" $RESFILE | awk '{print $NF}')
LINE="$LINE $TOKEN"


echo $LINE
LINE=""

VISC="Str"
RESFILE="CuPo${VISC}R200${PRECSTR}A67N4*"
TOKEN=$(grep "$TAG" $RESFILE | awk '{print $NF}')
LINE="$LINE $TOKEN"


RESFILE="CuPo${VISC}R200${PRECSTR}A67N6*"
TOKEN=$(grep "$TAG" $RESFILE | awk '{print $NF}')
LINE="$LINE $TOKEN"


RESFILE="CuPo${VISC}R200${PRECSTR}A67N8*"
TOKEN=$(grep "$TAG" $RESFILE | awk '{print $NF}')
LINE="$LINE $TOKEN"


RESFILE="CuPo${VISC}R200${PRECSTR}A67N10*"
TOKEN=$(grep "$TAG" $RESFILE | awk '{print $NF}')
LINE="$LINE $TOKEN"


RESFILE="CuPo${VISC}R200${PRECSTR}A67N12*"
TOKEN=$(grep "$TAG" $RESFILE | awk '{print $NF}')
LINE="$LINE $TOKEN"


RESFILE="CuPo${VISC}R200${PRECSTR}A67N14*"
TOKEN=$(grep "$TAG" $RESFILE | awk '{print $NF}')
LINE="$LINE $TOKEN"


RESFILE="CuPo${VISC}R200${PRECSTR}A67N16*"
TOKEN=$(grep "$TAG" $RESFILE | awk '{print $NF}')
LINE="$LINE $TOKEN"


RESFILE="CuPo${VISC}R200${PRECSTR}A67N18*"
TOKEN=$(grep "$TAG" $RESFILE | awk '{print $NF}')
LINE="$LINE $TOKEN"


echo $LINE

cd $CURRENTDIR


}


#RESDIR:
#test1_2v2Strn0-75cRSGs_oomph
#test2_2v2Strn0-75cRSEuclid_oomph
#test3_2v2Strn0-25cRSGs_oomph
#test4_2v2Strn0-50cRSGs_oomph
#test5_2v2Strn0-80cRSGs_oomph
#test6_2v2Strn0-90cRSGs_oomph
#test7_2v2Strn0-668cRSGs_oomph

#PREC:
#WeNlFa2v2Strn0-75cRSGsPe
#WeNlFa2v2Strn0-75cRSEuclidPe
#WeNlFa2v2Strn0-25cRSGsPe
#WeNlFa2v2Strn0-5cRSGsPe
#WeNlFa2v2Strn0-8cRSGsPe
#WeNlFa2v2Strn0-9cRSGsPe
#WeNlFa2v2Strn0-668cRSGsPe

#TAG:
#RAYAVGAVGITS
#RAYAVGAVGPRECSETUP
#RAYAVGAVGLINSOLVER


TAG="RAYAVGAVGITS"


RESDIR="test1_ang67_2v2cRSGs_oomph"
PRECSIM="WeNlFa2v2Strn0-25cRSGsPe"
PRECSTR="WeNlFa2v2Strn0-75cRSGsPe"
get_results

RESDIR="test2_ang67_1v2cRSGs_oomph"
PRECSIM="WeNlFa1v2Strn0-25cRSGsPe"
PRECSTR="WeNlFa1v2Strn0-75cRSGsPe"
get_results

echo ""
##########################
TAG="RAYAVGAVGPRECSETUP"
RESDIR="test1_ang67_2v2cRSGs_oomph"
PRECSIM="WeNlFa2v2Strn0-25cRSGsPe"
PRECSTR="WeNlFa2v2Strn0-75cRSGsPe"
get_results

RESDIR="test2_ang67_1v2cRSGs_oomph"
PRECSIM="WeNlFa1v2Strn0-25cRSGsPe"
PRECSTR="WeNlFa1v2Strn0-75cRSGsPe"
get_results


echo ""
##########################
TAG="RAYAVGAVGLINSOLVER"

RESDIR="test1_ang67_2v2cRSGs_oomph"
PRECSIM="WeNlFa2v2Strn0-25cRSGsPe"
PRECSTR="WeNlFa2v2Strn0-75cRSGsPe"
get_results

RESDIR="test2_ang67_1v2cRSGs_oomph"
PRECSIM="WeNlFa1v2Strn0-25cRSGsPe"
PRECSTR="WeNlFa1v2Strn0-75cRSGsPe"
get_results






