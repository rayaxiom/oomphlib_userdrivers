#!/bin/bash


run_test1_2v2Strn0-75cRSGs_oomph.sh > run_test1_2v2Strn0-75cRSGs_oomph.out 2>&1 && \
run_test2_2v2Strn0-75cRSEuclid_oomph.sh > run_test2_2v2Strn0-75cRSEuclid_oomph.out 2>&1 && \
run_test3_2v2Strn0-25cRSGs_oomph.sh > run_test3_2v2Strn0-25cRSGs_oomph.out 2>&1


