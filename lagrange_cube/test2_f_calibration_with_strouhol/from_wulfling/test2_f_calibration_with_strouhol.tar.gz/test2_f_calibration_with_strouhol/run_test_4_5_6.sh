#!/bin/bash


run_test4_2v2Strn0-50cRSGs_oomph.sh > run_test4_2v2Strn0-50cRSGs_oomph.out 2>&1 && \
run_test5_2v2Strn0-80cRSGs_oomph.sh > run_test5_2v2Strn0-80cRSGs_oomph.out 2>&1 && \
run_test6_2v2Strn0-90cRSGs_oomph.sh > run_test6_2v2Strn0-90cRSGs_oomph.out 2>&1 


